package com.mygdx.game.tanks;

public class DefensiveTank implements  Tank{
    private final String  TName= "DefensiveTank";
    private int damage;
    private int health;
    private int fuel;

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getFuel() {
        return fuel;
    }

    public void setFuel(int fuel) {
        this.fuel = fuel;
    }
    public String getTName() {
        return TName;
    }
    @Override
    public void specs() {
        this.damage= 25;//Damage from a standard distance
        this.health= 200;// Health of 200 units
        this.fuel=10;// tank can move to a certain distance
    }
}
