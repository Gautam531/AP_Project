package com.mygdx.game.tanks;

public class FuelEfficientTank implements Tank{
    private final String  TName= "FuelEfficientTank";
    private int damage;
    private int health;
    private int fuel;

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getFuel() {
        return fuel;
    }

    public void setFuel(int fuel) {
        this.fuel = fuel;
    }
    public String getTName() {
        return TName;
    }
    @Override
    public void specs() {
        this.damage= 28;//Damage from a standard distance
        this.health= 160;// Health of 160 units
        this.fuel=15;// tank can move to a certain distance
    }
}

