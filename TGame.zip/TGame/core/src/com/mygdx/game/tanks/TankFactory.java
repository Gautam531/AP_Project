package com.mygdx.game.tanks;

public class TankFactory {
    public Tank getInstance(String tname){
        if(tname.equals("PowerfulTank")){
            return new PowerfulTank();
        }
        else if (tname.equals("FuelEfficientTank")){
            return new FuelEfficientTank();
        }
        else{
            return new DefensiveTank();
        }
    }
}
