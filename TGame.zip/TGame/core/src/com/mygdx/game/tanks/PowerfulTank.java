package com.mygdx.game.tanks;

public class PowerfulTank  implements Tank{
    private final String TName= "PowerfulTank";
    private int damage;
    private int health;
    private int fuel;

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getFuel() {
        return fuel;
    }

    public void setFuel(int fuel) {
        this.fuel = fuel;
    }
    public String getTName() {
        return TName;
    }
    @Override
    public void specs() {
        this.damage=35; //Damage from a standard distance
        this.health=150;// Health of 150 units
        this.fuel=10; // tank can move to a certain distance depending upon fuel
    }
}
