package com.mygdx.game.tanks;

public interface Tank {
    String TName= "Tank";
    public void specs();
}
