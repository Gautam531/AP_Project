package com.mygdx.game.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.*;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.Scenes.Score_Life_Health;
import com.mygdx.game.TankShark;

public class RunningScreen implements Screen {
    private TankShark game;
    Texture texture;


    private OrthographicCamera gamecam;
    private Viewport gameport;
    private Score_Life_Health StaticScreen;

    private TmxMapLoader mapLoader;
    private TiledMap map;
    private OrthogonalTiledMapRenderer renderer;

    private World world;
    private Box2DDebugRenderer b2dr;
    //    private B2WorldCreator creator;
    public RunningScreen(TankShark game){
        this.game = game;
        texture = new Texture("LoadTankShark.jpg");

        gamecam = new OrthographicCamera();

        gameport = new FitViewport(800,480,gamecam);
        StaticScreen = Score_Life_Health.getInstance(game.batch);    //to display score life and health
        mapLoader = new TmxMapLoader();
        map = mapLoader.load("level2.tmx");
        renderer = new OrthogonalTiledMapRenderer(map,1/16f);
        gamecam.position.set(gameport.getWorldWidth() / 2,gameport.getWorldHeight()/2, 0);

        world = new World(new Vector2(0,0),true);      //for gravity
        b2dr = new Box2DDebugRenderer();

        BodyDef bdef = new BodyDef();
        PolygonShape shape = new PolygonShape();
        FixtureDef fdef = new FixtureDef();
        Body body;

        for (MapObject object : map.getLayers().get(2).getObjects().getByType(RectangleMapObject.class) ){
            Rectangle rectangle = ((RectangleMapObject) object).getRectangle();

            bdef.type = BodyDef.BodyType.KinematicBody;
            bdef.position.set(rectangle.getX()+rectangle.getWidth()/2,rectangle.getY()+rectangle.getHeight()/2);

            body = world.createBody(bdef);

            shape.setAsBox(rectangle.getWidth()/2,rectangle.getHeight()/2);
            fdef.shape = shape;
            body.createFixture(fdef);
        }

        for (MapObject object : map.getLayers().get(3).getObjects().getByType(RectangleMapObject.class) ){
            Rectangle rectangle = ((RectangleMapObject) object).getRectangle();

            bdef.type = BodyDef.BodyType.KinematicBody;
            bdef.position.set(rectangle.getX()+rectangle.getWidth()/2,rectangle.getY()+rectangle.getHeight()/2);

            body = world.createBody(bdef);

            shape.setAsBox(rectangle.getWidth()/2,rectangle.getHeight()/2);
            fdef.shape = shape;
            body.createFixture(fdef);
        }
//        creator = new B2WorldCreator(this);
    }

    @Override
    public void show() {

    }
    public void handleInput(float delta){
        if(Gdx.input.isTouched()){
            gamecam.position.x += 100*delta;}
    }
    public void update(float delta){
        handleInput(delta);
        gamecam.update();
        renderer.setView(gamecam);
    }

    @Override
    public void render(float delta) {
        update(delta);
        Gdx.gl.glClearColor(0,0,1,0.33f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        renderer.render();

        b2dr.render(world,gamecam.combined);

        game.batch.setProjectionMatrix(gamecam.combined);
        game.batch.begin();
        game.batch.draw(texture,0,0);
        game.batch.end();
//        game.batch.setProjectionMatrix(StaticScreen.stage.getCamera().combined);
//        StaticScreen.stage.draw();
    }

    @Override
    public void resize(int width, int height) {
        gameport.update(800,480);
    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
